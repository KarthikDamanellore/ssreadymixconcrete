import React from "react";
import AppRoutes from "./routes";
import { AppDataProvider } from "./providers/AppDataProvider";
import ReactGA from "react-ga";
import { useLocation } from "react-router-dom";

function App() {
  const location = useLocation();
  const TRACKING_ID = "G-E1031853M0"; // YOUR_OWN_TRACKING_ID
  ReactGA.initialize(TRACKING_ID);
  React.useEffect(() => {
    ReactGA.set({ page: location.pathname });
    ReactGA.pageview(location.pathname);
  }, [location]);
  return (
    <AppDataProvider>
      <AppRoutes />
    </AppDataProvider>
  );
}

export default App;
