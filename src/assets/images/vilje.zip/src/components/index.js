import NavBar from "./NavBar";
import Footer from "./Footer";

export { NavBar, Footer };
