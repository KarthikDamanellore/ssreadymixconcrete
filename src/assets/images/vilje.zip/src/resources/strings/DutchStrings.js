const common = {
  Home: "START",
  about: "ÜBER UNS",
  projects: "PROJEKTE",
  services: "DIENSTLEISTUNGEN",
  contacts: "KONTAKT",
  close: "SCHLIEßEN",
  english: "English",
  sweden: "Swedish",
  dutch: "Dutch",
};
const HomePage = {
  firstView: {
    headerTitle: "Wir bauen erstklassige digitale Lösungen.",
    headerDesc:
      "Vilje Tech reinvents the existing, scales the new, and develops digital solutions that will shape the future.",
    letsTalk: "REDEN MIT UNS",
  },
  secondView: {
    mainDescription:
      "Als Ingenieure und Kreative verstehen wir die Herausforderungen bei der Herstellung digitaler Produkte, die sowohl die Bedürfnisse von Unternehmen als auch von Benutzern erfüllen.",
    one: "01",
    two: "02",
    three: "03",
    design: "Design",
    develop: "Entwickeln",
    deliver: "Liefern",
    leftDesc:
      "Wir sind eine Entwicklungsagentur mit Sitz in Malmö, Skåne, Schweden, die mobile Anwendungen, Websites und kundenspezifische digitale Lösungen entwickelt, um Ihr Unternehmen zu skalieren.",
    moreAbout: "MEHR ÜBER UNS",
  },
  thirdView: {
    imvi: "imvi",
    imviDesc:
      "Verbessern visionen und sich gleichzeitig auf die bauen einer wirkungsvollen Benutzererfahrung konzentrieren.",
    foundi: "Foundi",
    foundiDesc:
      "Entwickeln des neuen Standards für verlorene und gefundene Lösungen.",
    bytboo: "Bytboo",
    bytbooDesc:
      "Helfen Ihnen, den besten Vermittler für Ihre Region zu finden.",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere. ",
    allProjects: "ALLE PROJEKTE",
  },
  fourthView: {
    appDevelopment: "App-Entwicklungen",
    webDevelopment: "Web Entwicklungen",
    uxUidesign: "UX- und UI-Design",
    ourServices: "UNSERE DIENSTLEISTUNGEN",
    appDevelopmentDesc: "",
    webDevelopmentDesc: "",
    uxUidesignDesc: "",
    itemDesc:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere.",
    clickHere: " Click to learn more",
  },
  fifthView: {
    testiMonial: "Testimonials",
    testiMonialDesc:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere.",
    cardDesc:
      "“Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere. ”",
    cardDesc1:
      "Vilje Tech hat unsere komplexe Augenkoordinationstrainings-App entwickelt und die Entwicklung effizient und qualitativ vom MVP bis zu einer vollständigen mobilen Anwendung optimiert. Unsere einzigartige Lösung hatte mehrere speziell eingebaute Funktionen, die Vilje Tech entwickelt hat. Sie hatten eine klare und transparente Kommunikation und waren während des gesamten Projekts stark involviert; wir werden weiter zusammenarbeiten. Wir empfehlen Vilje Tech.",
    cardDesc2:
      "Vilja Tech war für den Aufbau des Frontends von Bytboo verantwortlich, als wir das Produkt von Grund auf neu erstellten. Ich bin sehr zufrieden mit ihrer Arbeit. Kontinuierliche Updates auf dem Weg, pragmatisches Denken, das Lösungen für alle Hindernisse präsentiert, mit denen wir konfrontiert waren. Das Endergebnis war makellos. Ich kann Vilja Tech auf jeden Fall jedem Unternehmen empfehlen, das sich in der gleichen Situation wie Bytboo befindet.",
    name2: "Herman Treschow,",
    jobPosition2: "CEO Bytboo AB",
    name1: "David Olivas",
    jobPosition1: "Software consultant, Company, Sweden",
    header: "Trusted by many leading brands around the world",
  },
};
const FooterComponent = {
  title: "Lass uns gemeinsam etwas aufbauen!",
  contactUs: "Contact us",
  copyright: "Copyright © Vilje Tech Labs - All Rights Reserved",
  address: "Address: ",
  openInMaps: "Open in maps",
  email: "Email:",
  emailAddress: "bharath@vilja.tech",
  call: "Call:",
  phoneNo: "+46(0)724430170",
};
const AboutPage = {
  topView: {
    we: "Wir",
    design: "Design",
    develop: "Entwickeln",
    deliver: "Liefern",
    one: "/01",
    two: "/02",
    three: "/03",
    desc: "Vilje bedeutet: Wo ein Wille ist, ist auch ein Weg. Dieses ist unseren Motto und  es ermöglicht uns, unseren Kunden den besten Service, häufige, transparente Kommunikation und ein Endprodukt zu bieten, das alle Erwartungen übertrifft.",
    rightDesc1:
      "Wir entwerfen eine Projektstruktur, die einzigartig für Ihre Idee ist. Initiiert durch gründliche Recherchen, um den Markt und die Benutzer zu verstehen, schaffen wir eine stabile und strategisch begründete Basis, um die digitale Lösung für Ihre Bedürfnisse aufzubauen.",
    rightDesc2:
      "Unser Team aus hochqualifizierten Entwicklern kann jede Lösung erstellen, von einfachen Websites bis hin zu komplexen Blockchain-Technologien. Indem wir unserem kundenspezifischen Entwicklungsprozess folgen, können wir ein anpassungsfähiges und fehlerfreies Produkt sicherstellen.",
    rightDesc3:
      "Wir liefern ausgereifte Projekte. Und unsere Dienstleistungen hören hier nicht auf. Wir warten und aktualisieren Ihre Website und Anwendung, damit sie reibungslos funktionieren und den Standards entsprechen.",
  },
  middleView: {
    desc: "Unsere Vision ist es, die Welt zu verändern, indem wir die Ideen von morgen entwickeln. Kreationen, die den Status quo verändern und uns befähigen, für eine bessere Zukunft zu denken und zu handeln.",
    ourWork: "SEHEN SIE, WAS WIR TUN",
  },
  valuesView: {
    valueText: "Ein starkes Team entsteht aus starken Werten.",
    weaim: "Wir sind progressiv",
    weaimDesc: "Befürwortung kontinuierlicher Verbesserung.",
    wesupport: "WWir glauben an Synergie",
    wesupportDesc: "Indem wir als Team zusammenarbeiten, erschaffen wir Magie.",
    wenever: "Wir feiern Vielfalt",
    weneverDesc: "In Ideen, Menschen, Wissen und Kulturen. ",
    weleave: "Wir agieren integer",
    weleaveDesc:
      "Wahrhaftigkeit und Respekt in allem, was wir tun und erschaffen.",
  },
  bottomView: {
    meetOuraTeam: "Treffen unser Team",
    teamDesc:
      "Talent kennt keine Grenzen. Wir reisen lange und weit, um die Besten der Besten zu finden. Aber wir müssen nicht weit gehen, um zu sehen, dass unser Team unseren Kunden hervorragenden Service, Lösungen und Standards bietet.",
    name: "David Olivas",
    jobPosition: "Software developer",
  },
};
const ProjectsPage = {
  one: "/01",
  two: "/02",
  three: "/03",
  four: "/04",
  desc: "Hier ein kleiner Einblick in einige unserer bisherigen Arbeiten.",
  allProjects: "ALLE PROJEKTE",
  appDev: "APP-ENTWICKLUNG",
  webDev: "WEB ENTWICKLUNG",
  uiUx: "UX & UI DESIGN",
  imvi: "imvi",
  Foundi: "Foundi",
  Bytboo: "Bytbo",
  Prizbee: "Prizbe",
};
const ServicesPage = {
  firstView: {
    title: "Dienstleistungen",
    one: "/01",
    two: "/02",
    three: "/03",
    desc: "Wir sind ein Skandinavische Full-Stack-Entwicklungsunternehmen, das Websites und mobile Anwendungen erstellt, die außergewöhnlich aussehen und funktionieren. Mit ganzheitlichen Dienstleistungen in der Entwicklung haben wir Start-ups und etablierte Unternehmen in eine neue Ära der Digitalisierung geführt.",
    appDev: "App-Entwicklung",
    appDevDesc:
      "Wir erstellen und überarbeiten mobile Anwendungen, um Benutzer zu inspirieren, die Anpassung zu erweitern und den Umsatz zu steigern. Vilje Tech arbeitet mit Ihrem Unternehmen zusammen, um benutzerorientierte mobile Apps zu entwerfen, zu entwickeln und bereitzustellen. Durch einen iterativen und gründlichen Ansatz, der Strategie, Forschung, UI/UX-Design sowie Front- und Backend-Entwicklung umfasst, schaffen wir etwas, das die Welt verändern wird.",
    webDev: "Web Entwicklung",
    webDevDesc:
      "Eine gute Website etabliert Ihr Unternehmen, kommuniziert Ihre Markenidentität und baut Kundenbeziehungen auf. Vilje Tech entwickelt großartige Websites, die all das und noch viel mehr bieten. Indem wir Ihre Kunden verstehen, liefern wir Websites, die Ihre Marke stärken, sich auf die Benutzererfahrung konzentrieren und gesetzesfrei funktionieren.",
    uiUx: "UX- & UI-Design",
    uiUxDesc:
      "User Experience (UX) und User Interface (UI) Design sind entscheidende Faktoren für jedes digitale Produkt. Unser Designprozess umfasst das Verständnis der Benutzeranforderungen durch Recherche, Wireframing, High-Fidelity-Prototyping und Iteration basierend auf Benutzer-/Business-Feedback. Wir streben danach, ganzheitliche Erfahrungen zu schaffen, die Geschäftsanforderungen erfüllen und Endbenutzerprobleme lösen.",
  },
  secondView: {
    desc: "Wir entwickeln intelligente digitale Lösungen, die Startups und etablierte Unternehmen in die Lage versetzen, weiterzumachen",
    seeOurWork: "SEHEN SIE, WAS WIR TUN",
  },
  thirdView: {
    whyChoose: "Was spricht für uns -",
    Transparent: "Transparent ",
    TransparentDesc:
      "Während des gesamten Projekts ist unsere Hauptpriorität eine klare und transparente Kommunikation zwischen uns und unseren Kunden.",
    Reliable: "Zuverlässig",
    ReliableDesc:
      "Wir verstehen Ihre Reise und versuchen immer, eine Projektreise zu erstellen, die zu Ihren einzigartigen Produkten passt.",
    Explore: "Erkunden",
    ExploreDesc:
      "Für jedes neue Projekt führen wir Kunden-, Marken- und Produktforschung durch, um unseren Kunden Lösungen zu bieten, die nachweislich an ihren einzigartigen Markt angepasst sind.",
    creative: "Kreativ",
    creativeDesc:
      "Wir sind natürliche Kreative, die unsere Kunden dazu inspirieren wollen, in Design und Innovation über den Status Quo hinauszugehen.",
  },
  fourthView: {
    clientLoveUs: "Kunden empfehlen uns",
    clientDesc:
      "Glauben Sie uns nicht, hören Sie hier mehr von unserem Kunden.",
    cardDesc1:
      "“Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere. ”",
    name: "David Olivas",
    jobPosition: "Software consultant, Company, Sweden",
  },
};
const ContactPage = {
  title: "Contact",
  desc: "Haben Sie ein Projekt im Sinn, bitte kontaktieren Sie uns, um es zu verwirklichen.",
  name: "David Olivas",
  jobPosition: "Managing director, Vilje Tech Labs",
  email: "EMail",
  phone: "Phone",
  dividerText: "or drop us a line or two",
  yourName: "Your name*",
  yourEmail: "Your email address*",
  tellus: "Tell us about your project*",
  sendBtn: "Send message",
};
const imviPage = {
  heroSection: {
    heroHeader: "imvi Labs",
    client: "Client",
    clientName: "imvi Labs ",
    services: "Services",
    servicesDesc: "UX & UI design, App development, and Web development",
    links: "Links",
    linkText1: "Playstore - ",
    link1: "Lorem ipsum dolor",
    link2: "Lorem ipsum dolor",
    linktext2: "Appstore - ",
    overView: "Overview",
    overViewDesc:
      "Overview - Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  prblmSection: {
    headerText1: "Problem / Background",
    headerText2: "Solution",
    headerText3: "What we’ve done",
    headerText1Desc:
      "Unknown to most people, poor eye coordination significantly impacts energy, headaches, concentration, double vision and reading speed. To help improve the vision and reading skills of people, imvi Labs created a patented solution. They partnered up with Vilje Tech to turn theory into reality, an app that is straightforward but has a complex coded core. ",
    headerText2Desc:
      "Imvi Lab's wanted an app that motivated users to continue training. Vilje Tech offers a one-stop solution for developing the front and back end and designing the UX and UI. Therefore, we were a perfect choice.",
    headerText3Desc: {
      mainText1: "/01 - UX/UI design",
      mainText2: "/02 - App development",
      point1: {
        1: "Understanding user needs",
        2: "Wireframes",
        3: "High fidelity & Prototyping",
      },
      point2: {
        1: "Front end ",
        2: "Back end",
        3: "Adminpanel",
      },
    },
  },
  underStandingSection: {
    smallText: "(UX & UI design)",
    one: "01",
    headerText: "Understanding user needs",
    desc1: "Complex ",
    desc2: "Built from Ophthalmology (medical study of the eye)",
    desc3: "Entertainment integrations",
    desc4: "Eye coordination calibrations ",
    desc5: "Nudging",
    desc6: "Child and parent connection ",
  },
  wireFramesSection: {
    smallText: "(UX & UI design)",
    one: "02",
    headerText: "Wireframes",
    desc1: "Designing solution that motivates and entertain all ages",
    desc2: "Instructions",
    desc3: "Guiding the user through the functions ",
    desc4: "Speak with Rohith",
  },
  protoTypingSection: {
    smallText: "(UX & UI design)",
    one: "03",
    headerText: "High fidelity & Prototyping",
    desc: "Speak to Rohith ",
  },
  appDevSection: {
    smallText: "(App development)",
    one: "01",
    headerText: "App development",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  technologiesSection: {
    technologiesHeaderText: "Technologies used while developing -",
    technologies1: "Lorem ipsum",
    technologies2: "Lorem ipsum",
    technologies3: "Lorem ipsum",
  },
  resultsSection: {
    headerText: "Results",
    desc: "The result was an app that mixes fun and facts, and helps people both see and read better.",
    cardDesc:
      "The partnership between imvi Labs and Vilje Tech has continued as we work on developing the idea further and maintaining a great user experience. ",
    name: "David Olivas",
    jobposition: "Software consultant, Company, Sweden",
  },
};
const foundiPage = {
  heroSection: {
    heroHeader: "Foundi",
    client: "Client",
    clientName: "The team of Foundi",
    services: "Services",
    servicesDesc: "UX & UI design, App development, and Web development",
    links: "Links",
    linkText1: "Playstore - ",
    link1: "Lorem ipsum dolor",
    link2: "Lorem ipsum dolor",
    linktext2: "Appstore - ",
    overView: "Overview",
    overViewDesc:
      "Overview - Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  prblmSection: {
    headerText1: "Problem / Background",
    headerText2: "Solution",
    headerText3: "What we’ve done",
    headerText1Desc:
      "Lost something recently? Unfortunate but common, but we tend to lose our things. Foundi's studies show that 96% of the Swedish population loses at least one valuable item a year. Stressful and annoying, but there is an easy solution. Together we developed a strong brand identity and explored the most unique and effective solution. The result was a QR code bases solution that connects the user to their possessions. ",
    headerText2Desc:
      "Foundi needed a team to help them turn their vision into reality from start to finish. Their idea inspired us at Vilje Tech. The project started with brand identity and creating the app's and website's architecture and wireframes. To maximise traction and optimise the user experience, our copywriters and designers worked together to turn Foundi into a unique experience. Our collaboration is still ongoing, and we will follow Foundi into the launch and look forward to seeing them grow. ",
    headerText3Desc: {
      mainText1: "/01 - UX/UI design",
      mainText2: "/02 - App development",
      point1: {
        1: "Understanding user needs",
        2: "Wireframes",
        3: "High fidelity & Prototyping",
      },
      point2: {
        1: "Front end ",
        2: "Back end",
        3: "Adminpanel",
      },
    },
  },
  underStandingSection: {
    smallText: "(UX & UI design)",
    one: "01",
    headerText: "Branding",
    desc1: "A new solution requires clear instructions that gudies the user  ",
    desc2: "Branding that existes and captures attention from the user ",
    desc3:
      "For a new brand on the market it can be a challange to capture attention and stand out from other brands. With Foundi the client wanted a unique and colourful approach that would be eye catching along with a minimal and user friendly approach. ",
  },
  wireFramesSection: {
    smallText: "(UX & UI design)",
    one: "02",
    headerText: "Wireframes",
    desc1: "Integrated chat function ",
    desc2: "High security to keep both users inetegrity intact",
    desc3: "Creating an insentive to give back ",
  },
  protoTypingSection: {
    smallText: "(UX & UI design)",
    one: "03",
    headerText: "High fidelity & Prototyping",
    desc1: "Video introduction",
    desc2: "Easy visable buttons and short cuts when the user needs it ",
    desc3: "Registration process that is easy and smart - just like Foundi  ",
  },
  appDevSection: {
    smallText: "(App development)",
    one: "01",
    headerText: "App development",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  technologiesSection: {
    technologiesHeaderText: "Technologies used while developing -",
    technologies1: "Lorem ipsum",
    technologies2: "Lorem ipsum",
    technologies3: "Lorem ipsum",
  },
  resultsSection: {
    headerText: "Ongoing",
    desc: "Our collaboration with Foundi is still ongoing and we are looking forwad to Foundis launch and will be growing with them along the way.  ",
    cardDesc:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere.”",
    name: "David Olivas",
    jobposition: "Software consultant, Company, Sweden",
  },
};
const bytbooPage = {
  heroSection: {
    heroHeader: "Bytbo",
    client: "Client",
    clientName:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit - July 2022",
    services: "Services",
    servicesDesc: "UX & UI design, App development, and Web development",
    links: "Links",
    linkText1: "Playstore - ",
    link1: "Lorem ipsum dolor",
    link2: "Lorem ipsum dolor",
    linktext2: "Appstore - ",
    overView: "Overview",
    overViewDesc:
      "Overview - Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  prblmSection: {
    headerText1: "Problem / Background",
    headerText2: "Solution",
    headerText3: "What we’ve done",
    headerText1Desc:
      "The idea of Bytboo emerged from the realisation that the real estate industry has nearly no transparency. After extensive research, it was clear that the choice of a realtor affects the price when selling a home. ",
    headerText2Desc:
      "The solution was creating a service where users compare realtors, explore sales statistics and get economic insights within the housing market. Bytboo contacted Vilje Tech to develop their vision. They wanted a design with complex animations with click events, data handling and dynamic images with different colours. Challenges that we solved. The result was a website that allows for a seamless experience for the user while having high standards for function and quality.",
    headerText3Desc: {
      mainText1: "/01 - UX/UI design",
      mainText2: "/02 - App development",
      point1: {
        1: "Understanding user needs",
        2: "Wireframes",
        3: "High fidelity & Prototyping",
      },
      point2: {
        1: "Front end ",
        2: "Back end",
        3: "Adminpanel",
      },
    },
  },
  underStandingSection: {
    smallText: "(UX & UI design)",
    one: "01",
    headerText: "Understanding user needs",
    desc: "Understanding user needs",
  },
  wireFramesSection: {
    smallText: "(UX & UI design)",
    one: "02",
    headerText: "Wireframes",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  protoTypingSection: {
    smallText: "(UX & UI design)",
    one: "03",
    headerText: "High fidelity & Prototyping",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  appDevSection: {
    smallText: "(App development)",
    one: "01",
    headerText: "App development",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  technologiesSection: {
    technologiesHeaderText: "Technologies used while developing -",
    technologies1: "Lorem ipsum",
    technologies2: "Lorem ipsum",
    technologies3: "Lorem ipsum",
  },
  resultsSection: {
    headerText: "Results",
    desc: "We delivered a clean and engaging end product that packaged the Bytbo team's vision perfectly. We are proud to be apart of a more transparent real estate market.  ",
    cardDesc:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere.”",
    name: "David Olivas",
    jobposition: "Software consultant, Company, Sweden",
  },
};
const prizbeePage = {
  heroSection: {
    heroHeader: "Prizbe",
    client: "Client",
    clientName:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit - July 2022",
    services: "Services",
    servicesDesc: "UX & UI design, App development, and Web development",
    links: "Links",
    linkText1: "Playstore - ",
    link1: "Lorem ipsum dolor",
    link2: "Lorem ipsum dolor",
    linktext2: "Appstore - ",
    overView: "Overview",
    overViewDesc:
      "Overview - Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  prblmSection: {
    headerText1: "Problem / Background",
    headerText2: "Solution",
    headerText3: "What we’ve done",
    headerText1Desc:
      "Motivating children to learn can be challenging, especially in a world of digital distractions. Turn a challenge into an opportunity; that is what Prizbee did. Through their solutions, children get awarded for completing educational challenges with in-game tokens. Vilje Tech developed a playful and user-oriented front end to turn vision into reality",
    headerText2Desc:
      "The Prizbee team needed an agile, adaptive and communication-oriented team to develop their app. The requirement was to make a front end for an explicit MVP while working with a very international team of people from Ukraine and France. Our team provided strategic planning and focused on transparency and communication. Together our international team created an app with both a parent and child version that combined education, playfulness and integrations with well-known games.",
    headerText3Desc: {
      mainText1: "/01 - UX/UI design",
      mainText2: "/02 - App development",
      point1: {
        1: "Strategy and architecture",
        2: "UX & UI",
        3: "Tech Development",
      },
      point2: {
        1: " Maintenance ",
        2: "Back end",
        3: "Adminpanel",
      },
    },
  },
  underStandingSection: {
    smallText: "(UX & UI design)",
    one: "01",
    headerText: "Understanding user needs",
    desc: "Understanding user needs",
  },
  wireFramesSection: {
    smallText: "(UX & UI design)",
    one: "02",
    headerText: "Wireframes",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  protoTypingSection: {
    smallText: "(UX & UI design)",
    one: "03",
    headerText: "High fidelity & Prototyping",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  appDevSection: {
    smallText: "(App development)",
    one: "01",
    headerText: "App development",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vitae leo quis justo sollicitudin consectetur vel vel dolor. Cras venenatis magna felis, ut lobortis tellus laoreet ac. Duis a metus vel neque convallis tincidunt. Mauris dictum vel ipsum in fermentum. Integer lectus orci, imperdiet id volutpat vel, fermentum vel nunc. Aliquam facilisis varius vestibulum.",
  },
  technologiesSection: {
    technologiesHeaderText: "Technologies used while developing -",
    technologies1: "Lorem ipsum",
    technologies2: "Lorem ipsum",
    technologies3: "Lorem ipsum",
  },
  resultsSection: {
    headerText: "Results",
    desc: "Our collaboration with Prizbe is still ongoing and we are looking forward to be apart their journey and launch.  ",
    cardDesc:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis, lorem ac tempus posuere.”",
    name: "David Olivas",
    jobposition: "Software consultant, Company, Sweden",
  },
};
export const DutchStrings = {
  common,
  HomePage,
  FooterComponent,
  AboutPage,
  ProjectsPage,
  ServicesPage,
  ContactPage,
  imviPage,
  foundiPage,
  bytbooPage,
  prizbeePage,
};
