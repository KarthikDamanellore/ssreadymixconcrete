import HomePage from "./Home";
import AboutPage from "./About";
import ContactPage from "./Contact";
import ProjectsPage from "./Projects";
import ServicesPage from "./Services";
import CommingSoonPage from "./CommingSoonPage";
import PrizbeePage from "./PrizbeeProjectPage";
import FoundiPage from "./FoundiProjectPage";
import BytbooPage from "./BytbooProjectPage";
import ImviPage from "./ImviProjectPage";
import BlogList from "./BlogPosts/BlogList";
import BlogPost from "./BlogPosts/BlogPost";

export {
  HomePage,
  AboutPage,
  ContactPage,
  ProjectsPage,
  ServicesPage,
  CommingSoonPage,
  BytbooPage,
  FoundiPage,
  ImviPage,
  PrizbeePage,
  BlogList,
  BlogPost,
};
