import React, { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { Footer, NavBar } from "../../components";
import commonStyles from "../../assets/css/common.module.css";
import styles from "./styles.module.css";
import imviImg from "../../assets/images/imvi.png";
import { ArrowLeftLongIcon, ArrowRightLongIcon } from "../../components/Svg";
import { useAppData } from "../../providers/AppDataProvider";
import classNames from "classnames";
import photoImg from "../../assets/images/photoImg.svg";
import ebay from "../../assets/images/ebayImg.svg";
import aws from "../../assets/images/awsImg.svg";
import google from "../../assets/images/googleImg.svg";
import twitch from "../../assets/images/twitchImg.svg";
import ios from "../../assets/images/iosImg.svg";
import plus from "../../assets/images/plusIcon.svg";
import minus from "../../assets/images/minusIcon.svg";
import appDev from "../../assets/images/appDevIcon.svg";
import webDev from "../../assets/images/webDevIcon.svg";
import uiDesign from "../../assets/images/uiDesignIcon.svg";
import heroVideo from "../../assets/video/heroVideo.mp4";
import { Helmet } from "react-helmet";
import logoNewBlackImg from "../../assets/images/viljeNewLogoBlack.svg";

const HomePage = () => {
  const { strings } = useAppData();
  const [aDev, setADev] = useState(true);
  const [wDev, setWDev] = useState(false);
  const [uiDes, setUiDes] = useState(false);
  const [current, setCurrent] = useState(0);
  const [currentProject, setCurrentProject] = useState(1);
  const [currentIndex, setCurrentIndex] = useState(1);
  const [touchStart, setTouchStart] = useState(null);
  const [touchEnd, setTouchEnd] = useState(null);
  const [touchProjectStart, setTouchProjectStart] = useState(null);
  const [touchProjectEnd, setTouchProjectEnd] = useState(null);
  const ProjectsData = [
    {
      id: 1,
      project: strings.HomePage.thirdView.imvi,
      image: imviImg,
      desc: strings.HomePage.thirdView.imviDesc,
    },
    {
      id: 2,
      project: strings.HomePage.thirdView.foundi,
      image: imviImg,
      desc: strings.HomePage.thirdView.foundiDesc,
    },
    {
      id: 3,
      project: strings.HomePage.thirdView.bytboo,
      image: imviImg,
      desc: strings.HomePage.thirdView.bytbooDesc,
    },
  ];
  const Data = [
    {
      id: 1,
      desc: strings.HomePage.fifthView.cardDesc1,
      name: strings.HomePage.fifthView.name1,
      position: strings.HomePage.fifthView.jobPosition1,
    },
    {
      id: 2,
      desc: strings.HomePage.fifthView.cardDesc2,
      name: strings.HomePage.fifthView.name2,
      position: strings.HomePage.fifthView.jobPosition2,
    },
    {
      id: 3,
      desc: strings.HomePage.fifthView.cardDesc2,
      name: strings.HomePage.fifthView.name2,
      position: strings.HomePage.fifthView.jobPosition2,
    },
  ];
  useEffect(() => {
    loopFunction();
  }, [currentProject]);
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, []);
  function repeatContent(el, till) {
    let html = el.innerHTML;
    let counter = 0;

    while (el.offsetWidth < till && counter < 100) {
      el.innerHTML += html;
      counter += 1;
    }
  }
  const loopFunction = () => {
    let outer =
      document.querySelector("#outer") && document.querySelector("#outer");
    let content =
      outer.querySelector("#content") && outer.querySelector("#content");

    repeatContent(content, outer.offsetWidth);

    let el = outer.querySelector("#loop") && outer.querySelector("#loop");
    el.innerHTML = el.innerHTML + el.innerHTML;
  };
  const nextSlide = () => {
    setCurrentProject(
      currentProject <= 2 ? currentProject + 1 : currentProject
    );
  };
  const prevSlide = () => {
    setCurrentProject(
      currentProject >= 2 ? currentProject - 1 : currentProject
    );
  };
  const nextTestimonialSlide = () => {
    let slideIndex = currentIndex;
    if (currentIndex <= 2) {
      slideIndex = currentIndex + 1;
      setCurrentIndex(currentIndex + 1);
    }
    const ele = document.getElementById(`Data${slideIndex}`);
    ele.scrollIntoView({
      behavior: "smooth",
      block: "nearest",
      inline: "start",
    });
  };
  const prevTestimonialSlide = () => {
    let slideIndex = currentIndex;
    if (currentIndex > 0) {
      slideIndex = currentIndex - 1;
      setCurrentIndex(currentIndex - 1);
    }
    const ele = document.getElementById(`Data${slideIndex}`);
    ele.scrollIntoView({
      behavior: "smooth",
      block: "nearest",
      inline: "start",
    });
  };
  const minSwipeDistance = 50;
  const length = Data.length;
  const onTouchStart = (e) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e) => setTouchEnd(e.targetTouches[0].clientX);

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;
    if (isLeftSwipe) {
      setCurrent(current === length - 1 ? 0 : current + 1);
    } else if (isRightSwipe) {
      setCurrent(current === 0 ? length - 1 : current - 1);
    }
  };
  const onTouchProjectsStart = (e) => {
    setTouchProjectEnd(null);
    setTouchProjectStart(e.targetTouches[0].clientX);
  };

  const onTouchProjectsMove = (e) =>
    setTouchProjectEnd(e.targetTouches[0].clientX);

  const onTouchProjectsEnd = () => {
    if (!touchProjectStart || !touchProjectEnd) return;
    const distance = touchProjectStart - touchProjectEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;
    if (isLeftSwipe) {
      setCurrentProject(
        currentProject <= 2 ? currentProject + 1 : currentProject
      );
    } else if (isRightSwipe) {
      setCurrentProject(
        currentProject >= 2 ? currentProject - 1 : currentProject
      );
    }
  };
  const serviceSection = () => {
    return (
      <div className={styles.servicesSectionStyle}>
        <div className={styles.servicesTopContainerStyle}>
          <h3 className={styles.ourServicetextStyle}>
            {strings.HomePage.fourthView.ourServices}
          </h3>
          <p className={styles.ourServiceDescTextStyle}>
            {strings.HomePage.fourthView.itemDesc}
          </p>
        </div>
        <div className={styles.itemContainerStyle}>
          <div
            className={
              aDev ? styles.itemWrapper2Style : styles.itemWrapperStyle
            }
            onClick={() => setADev(!aDev)}
          >
            <div
              className={aDev ? styles.indexNumStyle : styles.indexNumStyle2}
            >
              <p className={aDev ? styles.numText2Style : styles.numTextStyle}>
                01
              </p>
            </div>
            <div
              className={
                aDev
                  ? styles.itemMiddleContentStyle2
                  : styles.itemMiddleContentStyle
              }
            >
              <div
                className={
                  aDev
                    ? styles.capsuleDevIcon2Style
                    : styles.capsuleDevIconStyle
                }
              >
                <img src={appDev} className={styles.imgStyle} />
              </div>

              <div className={styles.itenContentWrapperStyle}>
                <h2
                  className={
                    aDev ? styles.itemText2Style : styles.itemTextStyle
                  }
                >
                  {strings.HomePage.fourthView.appDevelopment}
                </h2>

                <p
                  className={
                    aDev ? styles.itemDescTextStyle : styles.itemDescText2Style
                  }
                >
                  {strings.HomePage.fourthView.itemDesc}
                  <span className={styles.itemDescTextLinkStyle}>
                    {strings.HomePage.fourthView.clickHere}
                  </span>
                </p>
              </div>
            </div>
            <div className={styles.capsuleImgWrapperStyle}>
              <div className={styles.imgClickStyle}>
                <img src={aDev ? minus : plus} className={styles.imgStyle} />
              </div>
            </div>
          </div>
          <div
            className={
              wDev ? styles.itemWrapper2Style : styles.itemWrapperStyle
            }
            onClick={() => setWDev(!wDev)}
          >
            <div
              className={wDev ? styles.indexNumStyle : styles.indexNumStyle2}
            >
              <p className={wDev ? styles.numText2Style : styles.numTextStyle}>
                02
              </p>
            </div>
            <div
              className={
                wDev
                  ? styles.itemMiddleContentStyle2
                  : styles.itemMiddleContentStyle
              }
            >
              <div
                className={
                  wDev
                    ? styles.capsuleDevIcon2Style
                    : styles.capsuleDevIconStyle
                }
              >
                <img src={webDev} className={styles.imgStyle} />
              </div>

              <div className={styles.itenContentWrapperStyle}>
                <h2
                  className={
                    wDev ? styles.itemText2Style : styles.itemTextStyle
                  }
                >
                  {strings.HomePage.fourthView.webDevelopment}
                </h2>

                <p
                  className={
                    wDev ? styles.itemDescTextStyle : styles.itemDescText2Style
                  }
                >
                  {strings.HomePage.fourthView.itemDesc}
                  <span className={styles.itemDescTextLinkStyle}>
                    {strings.HomePage.fourthView.clickHere}
                  </span>
                </p>
              </div>
            </div>
            <div className={styles.capsuleImgWrapperStyle}>
              <div className={styles.imgClickStyle}>
                <img src={wDev ? minus : plus} className={styles.imgStyle} />
              </div>
            </div>
          </div>
          <div
            className={
              uiDes ? styles.itemWrapper2Style : styles.itemWrapperStyle
            }
            onClick={() => setUiDes(!uiDes)}
          >
            <div
              className={uiDes ? styles.indexNumStyle : styles.indexNumStyle2}
            >
              <p className={uiDes ? styles.numText2Style : styles.numTextStyle}>
                03
              </p>
            </div>
            <div
              className={
                uiDes
                  ? styles.itemMiddleContentStyle2
                  : styles.itemMiddleContentStyle
              }
            >
              <div
                className={
                  uiDes
                    ? styles.capsuleDevIcon2Style
                    : styles.capsuleDevIconStyle
                }
              >
                <img src={uiDesign} className={styles.imgStyle} />
              </div>

              <div className={styles.itenContentWrapperStyle}>
                <h2
                  className={
                    uiDes ? styles.itemText2Style : styles.itemTextStyle
                  }
                >
                  {strings.HomePage.fourthView.uxUidesign}
                </h2>

                <p
                  className={
                    uiDes ? styles.itemDescTextStyle : styles.itemDescText2Style
                  }
                >
                  {strings.HomePage.fourthView.itemDesc}
                  <span className={styles.itemDescTextLinkStyle}>
                    {strings.HomePage.fourthView.clickHere}
                  </span>
                </p>
              </div>
            </div>
            <div className={styles.capsuleImgWrapperStyle}>
              <div className={styles.imgClickStyle}>
                <img src={uiDes ? minus : plus} className={styles.imgStyle} />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  const partnersSection = () => {
    return (
      <div className={styles.partnerSectionMainContainerStyle}>
        <div className={styles.partnersContainerStyle}>
          <div className={styles.testimonialContainerStyle}>
            <div className={styles.testimonialDescWrapperStyle}>
              <div>
                <h2 className={styles.testimonialTextStyle}>
                  {strings.HomePage.fifthView.testiMonial}
                </h2>
                <p className={styles.testimonialDescTextStyle}>
                  {strings.HomePage.fifthView.testiMonialDesc}
                </p>
              </div>
              <div className={styles.paSliderWrapperStyle}>
                <ArrowLeftLongIcon
                  color={
                    currentIndex <= 1 ? "rgba(0, 0, 0, 0.2)" : "rgb(0, 0, 0)"
                  }
                  onClick={() => prevTestimonialSlide()}
                />
                <ArrowRightLongIcon
                  color={
                    currentIndex >= 3 ? "rgba(0, 0, 0, 0.2)" : "rgb(0, 0, 0)"
                  }
                  onClick={() => nextTestimonialSlide()}
                />
              </div>
            </div>
            <div className={styles.cardsFlowStyle}>
              {Data.map((item, index) => {
                return (
                  <div
                    key={"Data" + item.id}
                    id={"Data" + item.id}
                    className={styles.testiMonialCardStyle}
                  >
                    <p className={styles.cardDescTextStyle}>{item.desc}</p>
                    <div className={styles.cardClientDetailsStyle}>
                      <div className={styles.clientImgWrapperStyle}>
                        <img src={photoImg} className={styles.imgStyle} />
                      </div>
                      <div>
                        <p className={styles.cardClientNametextStyle}>
                          {item.name}
                        </p>
                        <p className={styles.cardClientPositiontextStyle}>
                          {item.position}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className={styles.cardsFlowStyle2}>
              {Data.map((item, index) => {
                return (
                  <React.Fragment key={"plus" + index}>
                    {current === index && (
                      <div
                        className={styles.testiMonialCardStyle}
                        onTouchStart={onTouchStart}
                        onTouchMove={onTouchMove}
                        onTouchEnd={onTouchEnd}
                      >
                        <p className={styles.cardDescTextStyle}>{item.desc}</p>
                        <div className={styles.cardClientDetailsStyle}>
                          <div className={styles.clientImgWrapperStyle}>
                            <img src={photoImg} className={styles.imgStyle} />
                          </div>
                          <div>
                            <p className={styles.cardClientNametextStyle}>
                              {item.name}
                            </p>
                            <p className={styles.cardClientPositiontextStyle}>
                              {item.position}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </React.Fragment>
                );
              })}
            </div>
            <div className={styles.dotsContainerStyles}>
              {Data.map((item, index) => {
                return (
                  <div
                    key={"item" + index}
                    className={
                      current === index
                        ? styles.dotsSelectedStyle
                        : styles.dotsStyle
                    }
                    onClick={() => setCurrent(index)}
                  ></div>
                );
              })}
            </div>
          </div>
          <div className={styles.partnersWithContainerStyle}>
            <p className={styles.parnterDescTextStyle}>
              {strings.HomePage.fifthView.header}
            </p>

            <div className={styles.partnerImgContainerStyle}>
              <div className={styles.partnerImgWrapperStyle}>
                <div className={styles.partnerebayImgWrapperStyle}>
                  <img src={ebay} className={styles.imgStyle} />
                </div>
              </div>
              <div className={styles.partnerImgWrapperStyle}>
                <div className={styles.partnerawsImgWrapperStyle}>
                  <img src={aws} className={styles.imgStyle} />
                </div>
              </div>
              <div className={styles.partnerImgWrapperStyle}>
                <div className={styles.partnergoogleImgWrapperStyle}>
                  <img src={google} className={styles.imgStyle} />
                </div>
              </div>
              <div className={styles.partnerImgWrapperStyle}>
                <div className={styles.partnertwitchImgWrapperStyle}>
                  <img src={twitch} className={styles.imgStyle} />
                </div>
              </div>
              <div className={styles.partnerImgWrapperStyle}>
                <div className={styles.partneriosImgWrapperStyle}>
                  <img src={ios} className={styles.imgStyle} />
                </div>
              </div>
              <div className={styles.partnerImgWrapperStyle}>
                <div className={styles.partneriosImgWrapperStyle}>
                  <img src={ios} className={styles.imgStyle} />
                </div>
              </div>
              <div className={styles.partnerImgWrapperStyle}>
                <div className={styles.partneriosImgWrapperStyle}>
                  <img src={ios} className={styles.imgStyle} />
                </div>
              </div>
              <div className={styles.partnerImgWrapperStyle}>
                <div className={styles.partneriosImgWrapperStyle}>
                  <img src={ios} className={styles.imgStyle} />
                </div>
              </div>
              <div className={styles.partnerImgWrapperStyle}>
                <div className={styles.partneriosImgWrapperStyle}>
                  <img src={ios} className={styles.imgStyle} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  return (
    <div className={styles.containerStyle}>
      <Helmet>
        <meta
          name="description"
          content="Stay ahead with ViljeTech's tech solutions. Our experts offer web and app development, UX/UI design & more to thrive in today's digital world. Contact us to learn more!"
        />
        <meta
          name="keywords"
          content="Web development, Mobile app development, User experience, User interface, Design."
        />
        <link rel="canonical" href="https://www.viljetech.com/home" />
        <title>ViljeTech | We create world-class digital solutions. </title>
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org/",
            "@type": "Corporation",
            name: "ViljeTech",
            description: strings.HomePage.firstView.headerDesc,
            keywords:
              "Web development, Mobile app development, User experience, User interface, Design.",
            logo: [
              "https://www.viljetech.com/static/media/viljeNewLogoBlack.8252b5b1b505bf0bf9517de813c92e0c.svg",
            ],
            url: "https://www.viljetech.com/",
            foundingDate: new Date("2023-01-04T09:25:01.340Z").toISOString(),
            founder: {
              "@type": "Person",
              name: "Bharath Panayala",
            },
          })}
        </script>
      </Helmet>
      <NavBar />
      <div className={styles.topSectionStyle}>
        <div className={styles.topSectionInnerStyle}>
          <div className={styles.videoContainerStyle}>
            <video
              autoPlay
              loop
              muted
              playsInline
              controls={false}
              className={styles.videoStyle}
            >
              <source src={heroVideo} type="video/mp4" />
            </video>
          </div>
          <div className={styles.titleWrapperStyle}>
            <h1 className={styles.titleStyle}>
              {strings.HomePage.firstView.headerTitle}
            </h1>
          </div>
          <div className={styles.descriptionWrapperStyle}>
            <p className={styles.descriptionStyle}>
              {strings.HomePage.firstView.headerDesc}
            </p>
            <a
              href="#"
              className={classNames(
                commonStyles.anchorStyle,
                styles.anchorStyle
              )}
            >
              {strings.HomePage.firstView.letsTalk}
            </a>
          </div>
        </div>
      </div>
      <div className={styles.aboutSectionStyle}>
        <div className={styles.aboutSectionInnerStyle}>
          <p className={styles.aboutTitleStyle}>
            {strings.HomePage.secondView.mainDescription}
          </p>
          <div className={styles.aboutSectionBottomStyle}>
            <div className={styles.aboutListStyle}>
              <div className={styles.aboutListItemStyle}>
                <p className={styles.aboutListItemNumberStyle}>01</p>
                <h3 className={styles.aboutListItemTitleStyle}>
                  {strings.HomePage.secondView.design}
                </h3>
              </div>
              <div className={styles.aboutListItemStyle}>
                <p className={styles.aboutListItemNumberStyle}>02</p>
                <h3 className={styles.aboutListItemTitleStyle}>
                  {strings.HomePage.secondView.develop}
                </h3>
              </div>
              <div className={styles.aboutListItemStyle}>
                <p className={styles.aboutListItemNumberStyle}>03</p>
                <h3 className={styles.aboutListItemTitleStyle}>
                  {strings.HomePage.secondView.deliver}
                </h3>
              </div>
            </div>
            <div className={styles.aboutRightStyle}>
              <p className={styles.aboutRightDescriptionStyle}>
                {strings.HomePage.secondView.leftDesc}
              </p>
              <NavLink
                to={"/about"}
                className={classNames(
                  commonStyles.anchorStyle,
                  styles.aboutRightAnchorStyle
                )}
              >
                {strings.HomePage.secondView.moreAbout}
              </NavLink>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.projectsSectionContainerStyle}>
        {ProjectsData.map((item, index) => {
          return (
            <div key={"projects" + index}>
              {currentProject === index + 1 && (
                <div
                  className={styles.psSectionStyle}
                  onTouchStart={onTouchProjectsStart}
                  onTouchMove={onTouchProjectsMove}
                  onTouchEnd={onTouchProjectsEnd}
                >
                  <div id="outer" className={styles.outer}>
                    <div>
                      <div id="loop" className={styles.loop}>
                        <div id="content" className={styles.psScrollTitleStyle}>
                          <span className={styles.psScrollTitleSpanStyle}>
                            {item.project}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.psContentWrapperStyle}>
                    <div className={styles.psImgWrapperStyle}>
                      <img
                        src={item.image}
                        className={styles.psImgStyle}
                        alt=""
                      />
                    </div>
                    <div className={styles.psBottomWrapperStyle}>
                      <div className={styles.psDescWrapperStyle}>
                        <div className={styles.psDescInnerWrapperStyle}>
                          <p className={styles.psDescStyle}>{item.desc}</p>
                          <div>
                            <div className={styles.psSliderWrapperStyle}>
                              <ArrowLeftLongIcon
                                color={
                                  currentProject <= 1
                                    ? "rgba(0, 0, 0, 0.2)"
                                    : "rgb(0, 0, 0)"
                                }
                                onClick={() => prevSlide()}
                              />
                              <ArrowRightLongIcon
                                color={
                                  currentProject >= 3
                                    ? "rgba(0, 0, 0, 0.2)"
                                    : "rgb(0, 0, 0)"
                                }
                                onClick={() => nextSlide()}
                              />
                            </div>
                            <div className={styles.dotsContainerStyles}>
                              {ProjectsData.map((item, index) => {
                                return (
                                  <div
                                    key={"projectsData" + index}
                                    className={
                                      currentProject === index + 1
                                        ? styles.dotsSelectedStyle
                                        : styles.boxSliderStyle
                                    }
                                  ></div>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className={styles.psRightStyle}>
                        <NavLink
                          to={"/projects"}
                          className={classNames(
                            commonStyles.anchorStyle,
                            styles.psAnchorStyle
                          )}
                        >
                          {strings.HomePage.thirdView.allProjects}
                        </NavLink>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
      {serviceSection()}
      {partnersSection()}
      <Footer />
    </div>
  );
};

export default HomePage;
