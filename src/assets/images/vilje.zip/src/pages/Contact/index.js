import React, { useEffect, useRef } from "react";
import { NavBar } from "../../components/index";
import styles from "./styles.module.css";
import contactImg from "../../assets/images/contactImg.svg";
import mailImg from "../../assets/images/Mail.svg";
import callImg from "../../assets/images/call.svg";
import { FaLinkedinIn } from "react-icons/fa";
import { FiInstagram } from "react-icons/fi";
import { BsTwitter } from "react-icons/bs";
import { FaFacebookF } from "react-icons/fa";
import { useAppData } from "../../providers/AppDataProvider";
import emailjs from "@emailjs/browser";
import { Helmet } from "react-helmet";

const ContactPage = () => {
  const { strings } = useAppData();
  const form = useRef();
  const contactData = [
    {
      id: 1,
      image: contactImg,
      name: strings.ContactPage.name,
      position: strings.ContactPage.jobPosition,
      email: strings.ContactPage.email,
      phone: strings.ContactPage.phone,
    },
    {
      id: 2,
      image: contactImg,
      name: strings.ContactPage.name,
      position: strings.ContactPage.jobPosition,
      email: strings.ContactPage.email,
      phone: strings.ContactPage.phone,
    },
  ];
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, []);
  const sendEmail = (e) => {
    e.preventDefault();

    emailjs
      .sendForm(
        "service_4rzxitg",
        "template_qnzyogg",
        form.current,
        "BCL0VqeQ06EXqocoa"
      )
      .then(
        (result) => {
          e.target.reset();
        },
        (error) => {
          console.log("error", error);
        }
      );
  };
  const renderContactImageView = () => {
    return (
      <div>
        <h1 className={styles.contactPageHeaderStyle}>
          {strings.ContactPage.title}
        </h1>

        <p className={styles.contactPageDescStyle}>
          {strings.ContactPage.desc}
        </p>
        <div className={styles.contactImgOutsideContainer}>
          {contactData.map((item, index) => {
            return (
              <div key={index} className={styles.contactImgInsideContainer}>
                <div className={styles.contactImgOfMemberStyle}>
                  <img src={item.image} className={styles.imgContactStyle} />
                </div>
                <p className={styles.contactNameStyle}>{item.name}</p>
                <p className={styles.contactPositionStyle}>{item.position}</p>
                <div className={styles.mailAndCallContainerStyle}>
                  <div className={styles.mailAndCallInsideContainerStyle}>
                    <div className={styles.imgContactContainerStyle}>
                      <img src={mailImg} className={styles.imgContactStyle} />
                    </div>
                    <p className={styles.contactDetailsText}>{item.email}</p>
                  </div>
                  <div className={styles.mailAndCallInsideContainerStyle}>
                    <div className={styles.imgContactContainerStyle}>
                      <img src={callImg} className={styles.imgContactStyle} />
                    </div>
                    <p className={styles.contactDetailsText}>{item.phone}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };
  const renderDividerView = () => {
    return (
      <div className={styles.dividerOuterWrapper}>
        <div className={styles.dividerWrapperStyle}>
          <div className={styles.dividerLineStyle}></div>
          <p className={styles.dividerLineTextStyle}>
            {strings.ContactPage.dividerText}
          </p>
          <div className={styles.dividerLineStyle}></div>
        </div>
      </div>
    );
  };
  const renderContactInputView = () => {
    return (
      <div className={styles.inputTextContainerStyle}>
        <form ref={form} onSubmit={sendEmail}>
          <input
            type={"text"}
            name="name"
            placeholder={strings.ContactPage.yourName}
            className={styles.inputTextViewStyle}
          />
          <input
            type={"email"}
            name="email"
            placeholder={strings.ContactPage.yourEmail}
            className={styles.inputTextViewStyle}
          />
          <textarea
            name="message"
            placeholder={strings.ContactPage.tellus}
            className={styles.inputTextAreaViewStyle}
          />
          <button type="submit" className={styles.submitButtonStyle}>
            {strings.ContactPage.sendBtn}
          </button>
        </form>
      </div>
    );
  };

  const rendderFooterContainer = () => {
    return (
      <div className={styles.footerContainerStyle}>
        <div className={styles.addressContainerStyle}>
          <p className={styles.addressTextStyle}>
            {strings.FooterComponent.address}
            <a className={styles.addressTextLinkStyle}>
              {strings.FooterComponent.openInMaps}
            </a>
          </p>
          <p className={styles.addressTextStyle}>
            {strings.FooterComponent.email}
            <a className={styles.addressTextLinkStyle}>
              {strings.FooterComponent.emailAddress}
            </a>
          </p>
          <p className={styles.addressTextStyle}>
            {strings.FooterComponent.call}
            <a className={styles.addressTextLinkStyle}>
              {strings.FooterComponent.phoneNo}
            </a>
          </p>
        </div>
        <div className={styles.socialIconContainerStyle}>
          <div className={styles.iconWrapperStyle}>
            <FaLinkedinIn color={"#ffffff"} className={styles.iconsStyle} />
          </div>
          <div className={styles.iconWrapperStyle}>
            <FiInstagram color={"#ffffff"} className={styles.iconsStyle} />
          </div>
          <div className={styles.iconWrapperStyle}>
            <BsTwitter color={"#ffffff"} className={styles.iconsStyle} />
          </div>
          <div className={styles.iconWrapperStyle}>
            <FaFacebookF color={"#ffffff"} className={styles.iconsStyle} />
          </div>
        </div>
        <p className={styles.footerCopyrightTextStyle}>
          {strings.ContactPage.copyright}
        </p>
      </div>
    );
  };

  const renderContactView = () => {
    return (
      <div className={styles.contactContainerStyle}>
        {renderContactImageView()}
        {renderDividerView()}
        {renderContactInputView()}
      </div>
    );
  };

  return (
    <div>
      <Helmet>
        <meta
          name="description"
          content="Transform your vision into reality - Contact us today to bring your project to life. We offer custom software solutions for your business needs.
          "
        />
        <meta name="keywords" content="Contact us,Get in touch,Reach out" />
        <link rel="canonical" href="https://www.viljetech.com/contact" />
        <title>ViljeTech | Contact us</title>
      </Helmet>
      <div className={styles.mainContactContainer}>
        <NavBar />
        <div className={styles.contactMainInsideContainer}>
          {renderContactView()}
        </div>
      </div>
      {rendderFooterContainer()}
    </div>
  );
};

export default ContactPage;
