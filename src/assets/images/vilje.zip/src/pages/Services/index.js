import React, { useState, useEffect } from "react";
import { Footer, NavBar } from "../../components";
import commonStyles from "../../assets/css/common.module.css";
import styles from "./styles.module.css";
import quoteImg from "../../assets/images/doubleQuote.svg";
import { useAppData } from "../../providers/AppDataProvider";
import photoImg from "../../assets/images/photoImg.svg";
import classNames from "classnames";
import { ArrowLeftLongIcon, ArrowRightLongIcon } from "../../components/Svg";
import { Helmet } from "react-helmet";

const ServicesPage = () => {
  const { strings } = useAppData();
  const [touchStart, setTouchStart] = useState(null);
  const [touchEnd, setTouchEnd] = useState(null);
  const clientData = [
    {
      id: 1,
      name: strings.ServicesPage.fourthView.name,
      company: strings.ServicesPage.fourthView.jobPosition,
      content: strings.ServicesPage.fourthView.cardDesc1,
    },
    {
      id: 2,
      name: strings.ServicesPage.fourthView.name,
      company: strings.ServicesPage.fourthView.jobPosition,
      content: strings.ServicesPage.fourthView.cardDesc1,
    },
    {
      id: 3,
      name: strings.ServicesPage.fourthView.name,
      company: strings.ServicesPage.fourthView.jobPosition,
      content: strings.ServicesPage.fourthView.cardDesc1,
    },
    {
      id: 4,
      name: strings.ServicesPage.fourthView.name,
      company: strings.ServicesPage.fourthView.jobPosition,
      content: strings.ServicesPage.fourthView.cardDesc1,
    },
  ];
  const [current, setCurrent] = useState(0);
  const [currentIndex, setCurrentIndex] = useState(1);
  const minSwipeDistance = 50;
  const length = clientData.length;
  const onTouchStart = (e) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e) => setTouchEnd(e.targetTouches[0].clientX);

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;
    if (isLeftSwipe) {
      setCurrent(current === length - 1 ? 0 : current + 1);
    } else if (isRightSwipe) {
      setCurrent(current === 0 ? length - 1 : current - 1);
    }
  };
  const nextTestimonialSlide = () => {
    let slideIndex = currentIndex;
    if (currentIndex <= 2) {
      slideIndex = currentIndex + 1;
      setCurrentIndex(currentIndex + 1);
    }
    const ele = document.getElementById(`client${slideIndex}`);
    ele.scrollIntoView({
      behavior: "smooth",
      block: "nearest",
      inline: "start",
    });
  };
  const prevTestimonialSlide = () => {
    let slideIndex = currentIndex;
    if (currentIndex > 1) {
      slideIndex = currentIndex - 1;
      setCurrentIndex(currentIndex - 1);
    }
    const ele = document.getElementById(`client${slideIndex}`);
    ele.scrollIntoView({
      behavior: "smooth",
      block: "nearest",
      inline: "start",
    });
  };
  const renderServicesTopContainer = () => {
    return (
      <div className={styles.servicesTopContainer}>
        <div className={styles.descriptionWrapperStyle}>
          <h1 className={styles.headerTextStyle}>
            {strings.ServicesPage.firstView.title}
          </h1>
          <p className={styles.descriptionTextStyle}>
            {strings.ServicesPage.firstView.desc}
          </p>
        </div>
        <div className={styles.servicesSectionContainerStyle}>
          <div className={styles.leftSectionStyle}>
            <p className={styles.leftSectionNumberStyle}>
              {strings.ServicesPage.firstView.one}
            </p>
          </div>
          <div className={styles.leftSectionStyle}>
            <h2 className={styles.leftSectionHeaderTextStyle}>
              {strings.ServicesPage.firstView.appDev}
            </h2>
            <p className={styles.leftSectionTextStyle}>
              {strings.ServicesPage.firstView.appDevDesc}
            </p>
          </div>
        </div>
        <div className={styles.servicesSectionContainerStyle}>
          <div className={styles.leftSectionStyle}>
            <p className={styles.leftSectionNumberStyle}>
              {strings.ServicesPage.firstView.two}
            </p>
          </div>
          <div className={styles.leftSectionStyle}>
            <h2 className={styles.leftSectionHeaderTextStyle}>
              {strings.ServicesPage.firstView.webDev}
            </h2>
            <p className={styles.leftSectionTextStyle}>
              {strings.ServicesPage.firstView.webDevDesc}
            </p>
          </div>
        </div>
        <div className={styles.servicesSectionContainerStyle}>
          <div className={styles.leftSectionStyle}>
            <p className={styles.leftSectionNumberStyle}>
              {strings.ServicesPage.firstView.three}
            </p>
          </div>
          <div className={styles.leftSectionStyle}>
            <h2 className={styles.leftSectionHeaderTextStyle}>
              {strings.ServicesPage.firstView.uiUx}
            </h2>
            <p className={styles.leftSectionTextStyle}>
              {strings.ServicesPage.firstView.uiUxDesc}
            </p>
          </div>
        </div>
      </div>
    );
  };
  const renderServicesOurWorkContainer = () => {
    return (
      <div className={styles.servicesOurWorkinsideContainerStyle}>
        <div className={styles.quoteImgContainerStyle}>
          <img src={quoteImg} className={styles.quoteImgStyle} />
        </div>

        <div className={styles.ourWorkDescContainerStyle}>
          <p className={styles.servicesOurWorkDescTextStyle}>
            {strings.ServicesPage.secondView.desc}
          </p>
          <a
            className={classNames(
              commonStyles.anchorStyle,
              styles.seeOurTextStyle
            )}
          >
            {strings.ServicesPage.secondView.seeOurWork}
          </a>
        </div>
      </div>
    );
  };
  const renderWhyChooseUsContainer = () => {
    return (
      <div className={styles.whyChooseContainerStyle}>
        <h2 className={styles.whyChooseUsTextStyle}>
          {strings.ServicesPage.thirdView.whyChoose}
        </h2>
        <div className={styles.whyChooseUsDescContainerStyle}>
          <div className={styles.whychooseUsFirstDescStyle}>
            <h3 className={styles.whyChooseUsHeaderTextStyle}>
              {strings.ServicesPage.thirdView.Transparent}
            </h3>
            <p className={styles.whyChooseUsDescTextStyle}>
              {strings.ServicesPage.thirdView.TransparentDesc}
            </p>
          </div>
          <div className={styles.whychooseUsFirstDescStyle}>
            <h3 className={styles.whyChooseUsHeaderTextStyle}>
              {strings.ServicesPage.thirdView.Reliable}
            </h3>
            <p className={styles.whyChooseUsDescTextStyle}>
              {strings.ServicesPage.thirdView.ReliableDesc}
            </p>
          </div>

          <div className={styles.whychooseUsFirstDescStyle}>
            <h3 className={styles.whyChooseUsHeaderTextStyle}>
              {strings.ServicesPage.thirdView.Explore}
            </h3>
            <p className={styles.whyChooseUsDescTextStyle}>
              {strings.ServicesPage.thirdView.ExploreDesc}
            </p>
          </div>
          <div className={styles.whychooseUsFirstDescStyle}>
            <h3 className={styles.whyChooseUsHeaderTextStyle}>
              {strings.ServicesPage.thirdView.creative}
            </h3>
            <p className={styles.whyChooseUsDescTextStyle}>
              {strings.ServicesPage.thirdView.creativeDesc}
            </p>
          </div>
        </div>
      </div>
    );
  };
  const renderServicesClientContainer = () => {
    return (
      <div className={styles.servicesClientinsideContainerStyle}>
        <div className={styles.clientTopSectionInsideContainerStyle}>
          <h2 className={styles.clientContainerHeaderStyle}>
            {strings.ServicesPage.fourthView.clientLoveUs}
          </h2>
          <p className={styles.clientContainerDescStyle}>
            {strings.ServicesPage.fourthView.clientDesc}
          </p>
        </div>

        <div className={styles.clientsDetailsGridStyle}>
          {clientData.map((item, index) => {
            return (
              <div
                key={"client" + item.id}
                id={"client" + item.id}
                className={styles.clientsDetailsCardStyle}
              >
                <p className={styles.clientsDetailsCardContentStyle}>
                  {item.content}
                </p>
                <div className={styles.clientContainerStyle}>
                  <div className={styles.photoImgWrapperStyle}>
                    <img src={photoImg} className={styles.imgStyle} />
                  </div>
                  <div>
                    <p className={styles.clientsDetailsCardNameStyle}>
                      {item.name}
                    </p>
                    <p className={styles.clientsDetailsCardCompanyStyle}>
                      {item.company}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <div className={styles.psSliderWrapperStyle}>
          <ArrowLeftLongIcon
            color={currentIndex <= 1 ? "rgba(0, 0, 0, 0.2)" : "rgb(0, 0, 0)"}
            onClick={() => prevTestimonialSlide()}
          />
          <ArrowRightLongIcon
            color={currentIndex >= 3 ? "rgba(0, 0, 0, 0.2)" : "rgb(0, 0, 0)"}
            onClick={() => nextTestimonialSlide()}
          />
        </div>
        <div className={styles.clientsDetailsGridStyle2}>
          {clientData.map((item, index) => {
            return (
              <React.Fragment key={"clientData" + index}>
                {current === index && (
                  <div
                    className={styles.clientsDetailsCardStyle}
                    onTouchStart={onTouchStart}
                    onTouchMove={onTouchMove}
                    onTouchEnd={onTouchEnd}
                  >
                    <p className={styles.clientsDetailsCardContentStyle}>
                      {item.content}
                    </p>
                    <div className={styles.clientContainerStyle}>
                      <div className={styles.photoImgWrapperStyle}>
                        <img src={photoImg} className={styles.imgStyle} />
                      </div>
                      <div>
                        <p className={styles.clientsDetailsCardNameStyle}>
                          {item.name}
                        </p>
                        <p className={styles.clientsDetailsCardCompanyStyle}>
                          {item.company}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>
        <div className={styles.dotsContainerStyles}>
          {clientData.map((item, index) => {
            return (
              <div
                key={"item" + index}
                className={
                  current === index
                    ? styles.dotsSelectedStyle
                    : styles.dotsStyle
                }
                onClick={() => setCurrent(index)}
              ></div>
            );
          })}
        </div>
      </div>
    );
  };
  return (
    <div className={styles.mainContainer}>
      <Helmet>
        <meta
          name="description"
          content="Transform your business with ViljeTech's expert web and app development and cutting-edge solutions. Boost your success with our services. Learn more."
        />
        <meta
          name="keywords"
          content="Services, Web development, Mobile app development, User experience, User interface, Design. "
        />
        <link rel="canonical" href="https://www.viljetech.com/services" />
        <title>ViljeTech | Our Services </title>
      </Helmet>
      <NavBar color={true} />
      <div className={styles.servicesContainerStyle}>
        {renderServicesTopContainer()}
      </div>
      <div className={styles.servicesOurWorkContainerStyle}>
        <div className={styles.servicesOurWorkOutsideContainerStyle}>
          {renderServicesOurWorkContainer()}
        </div>
      </div>
      <div className={styles.servicesContainerStyle}>
        {renderWhyChooseUsContainer()}
      </div>
      <div className={styles.servicesClientContainerStyle}>
        <div className={styles.servicesClientOutsideContainerStyle}>
          {renderServicesClientContainer()}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ServicesPage;
