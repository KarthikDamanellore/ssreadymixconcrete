import React, { useState, useEffect } from "react";
import classNames from "classnames";
import { Footer, NavBar } from "../../components";
import commonStyles from "../../assets/css/common.module.css";
import styles from "./styles.module.css";
import architectImg from "../../assets/images/architects.png";
import realityImg from "../../assets/images/reality.png";
import qritImg from "../../assets/images/qrit.png";
import fashionImg from "../../assets/images/fashion.png";
import { useNavigate } from "react-router-dom";
import { useAppData } from "../../providers/AppDataProvider";
import { Helmet } from "react-helmet";

const ProjectsPage = () => {
  const { strings } = useAppData();
  const navigate = useNavigate();
  const [active, setActive] = useState("all");
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, []);
  return (
    <div className={styles.containerStyle}>
      <Helmet>
        <meta
          name="description"
          content="Explore our portfolio of successful projects and see the results for yourself. ViljeTech's expertise and innovative solutions speak for themselves."
        />
        <meta
          name="keywords"
          content="Projects, Client testimonials, Portfolio"
        />
        <link rel="canonical" href="https://www.viljetech.com/projects" />
        <title>ViljeTech | Previous Projects</title>
      </Helmet>
      <div className={styles.projectsHeaderSectionStyle}>
        <NavBar color={true} />
        <div className={styles.projectsSectionStyle}>
          <div className={styles.phsInnerStyle}>
            <p className={styles.phsDescStyle}>{strings.ProjectsPage.desc}</p>
            <div className={styles.phsListStyle}>
              <a
                href="#"
                className={classNames(
                  active === "all"
                    ? styles.phsListItemActiveStyle
                    : commonStyles.anchorStyle,
                  styles.phsListItemStyle
                )}
                onClick={() => setActive("all")}
              >
                {strings.ProjectsPage.allProjects}
              </a>
              <a
                href="#"
                className={classNames(
                  active === "app"
                    ? styles.phsListItemActiveStyle
                    : commonStyles.anchorStyle,
                  styles.phsListItemStyle
                )}
                onClick={() => setActive("app")}
              >
                {strings.ProjectsPage.appDev}
              </a>
              <a
                href="#"
                className={classNames(
                  active === "web"
                    ? styles.phsListItemActiveStyle
                    : commonStyles.anchorStyle,
                  styles.phsListItemStyle
                )}
                onClick={() => setActive("web")}
              >
                {strings.ProjectsPage.webDev}
              </a>
              <a
                href="#"
                className={classNames(
                  active === "ui"
                    ? styles.phsListItemActiveStyle
                    : commonStyles.anchorStyle,
                  styles.phsListItemStyle
                )}
                onClick={() => setActive("ui")}
              >
                {strings.ProjectsPage.uiUx}
              </a>
            </div>
          </div>
          <div className={styles.plsInnerStyle}>
            <div
              className={styles.plsListItemStyle}
              onClick={() => navigate("/projects/imvi")}
            >
              <p className={styles.plsListItemNumberStyle}>
                {strings.ProjectsPage.one}
              </p>
              <h2 className={styles.plsListItemTitleStyle}>
                {strings.ProjectsPage.imvi}
              </h2>
              <img
                src={architectImg}
                className={styles.plsListItemImgStyle}
                alt=""
              />
            </div>
            <div
              className={styles.plsListItemStyle}
              onClick={() => navigate("/projects/foundi")}
            >
              <p className={styles.plsListItemNumberStyle}>
                {strings.ProjectsPage.two}
              </p>
              <h2 className={styles.plsListItemTitleStyle}>
                {strings.ProjectsPage.Foundi}
              </h2>
              <img
                src={realityImg}
                className={styles.plsListItemImgStyle}
                alt=""
              />
            </div>
            <div
              className={styles.plsListItemStyle}
              onClick={() => navigate("/projects/bytboo")}
            >
              <p className={styles.plsListItemNumberStyle}>
                {strings.ProjectsPage.three}
              </p>
              <h2 className={styles.plsListItemTitleStyle}>
                {strings.ProjectsPage.Bytboo}
              </h2>
              <img
                src={qritImg}
                className={styles.plsListItemImgStyle}
                alt=""
              />
            </div>
            <div
              className={styles.plsListItemStyle}
              onClick={() => navigate("/projects/prizbee")}
            >
              <p className={styles.plsListItemNumberStyle}>
                {strings.ProjectsPage.four}
              </p>
              <h2 className={styles.plsListItemTitleStyle}>
                {strings.ProjectsPage.Prizbee}
              </h2>
              <img
                src={fashionImg}
                className={styles.plsListItemImgStyle}
                alt=""
              />
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ProjectsPage;
