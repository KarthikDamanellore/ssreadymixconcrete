import React, { useEffect } from "react";
import styles from "./styles.module.css";
import { Footer, NavBar } from "../../components";
import architectImg from "../../assets/images/architectPageImg.svg";
import photo from "../../assets/images/photoPicAbout.svg";
import webDevBlueImg from "../../assets/images/webDevBlueImg.svg";
import webDevBlackImg from "../../assets/images/webDevBlackImg.svg";
import quoteImg from "../../assets/images/doubleQuote.svg";
import quoteBlackImg from "../../assets/images/quoteBlackImg.svg";
import photoImg from "../../assets/images/photoImg.svg";
import { useAppData } from "../../providers/AppDataProvider";
import { Helmet } from "react-helmet";

const FoundiPage = () => {
  const { strings } = useAppData();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, []);
  const renderHeaderTopContainer = () => {
    return (
      <div className={styles.headerTopContainerStyles}>
        <h1 className={styles.headerTextStyle}>
          {strings.foundiPage.heroSection.heroHeader}
        </h1>
        <div className={styles.imgWrapperStyles}>
          <img src={architectImg} className={styles.imgStyles} />
        </div>
        <div className={styles.clientsContainerStyle}>
          <div className={styles.overViewContainerStyle}>
            <h3 className={styles.overViewTextStyle}>
              {strings.foundiPage.heroSection.overView}
            </h3>
            <p className={styles.overViewDescTextStyle}>
              {strings.foundiPage.heroSection.overViewDesc}
            </p>
          </div>
          <div className={styles.clientsOutsideContainerStyle}>
            <div className={styles.clientsInsideContainerStyle}>
              <h3 className={styles.clientHeaderStyles}>
                {strings.foundiPage.heroSection.client}
              </h3>
              <p className={styles.clientBottomTextStyle}>
                {strings.foundiPage.heroSection.clientName}
              </p>
            </div>
            <div className={styles.clientsInsideContainerStyle}>
              <h3 className={styles.clientHeaderStyles}>
                {strings.foundiPage.heroSection.services}
              </h3>
              <p className={styles.clientBottomTextStyle}>
                {strings.foundiPage.heroSection.servicesDesc}
              </p>
            </div>
            <div className={styles.clientsInsideContainerStyle}>
              <h3 className={styles.clientHeaderStyles}>
                {strings.foundiPage.heroSection.links}
              </h3>
              <div className={styles.linkContainerStyle}>
                <p className={styles.clientBottomTextStyle}>
                  {strings.foundiPage.heroSection.linkText1}
                  <a className={styles.linkStyle}>
                    {strings.foundiPage.heroSection.link1}
                  </a>
                </p>
                <p className={styles.clientBottomTextStyle}>
                  {strings.foundiPage.heroSection.linktext2}
                  <a className={styles.linkStyle}>
                    {strings.foundiPage.heroSection.link2}
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  const renderPrblmSolutionContainer = () => {
    return (
      <div className={styles.prblmSolutionMainContainerStyle}>
        <div className={styles.prblmSolinsideContainerStyle}>
          <div className={styles.itemInsideWrapperStyle}>
            <h3 className={styles.prblmHeaderTextStyle}>
              {strings.foundiPage.prblmSection.headerText1}
            </h3>
            <p className={styles.prblmSoluDescTextStyle}>
              {strings.foundiPage.prblmSection.headerText1Desc}
            </p>
          </div>
          <div className={styles.itemInsideWrapperStyle}>
            <h3 className={styles.prblmHeaderTextStyle}>
              {strings.foundiPage.prblmSection.headerText2}
            </h3>
            <p className={styles.prblmSoluDescTextStyle}>
              {strings.foundiPage.prblmSection.headerText2Desc}
            </p>
          </div>
          <div className={styles.itemInsideWrapperStyle}>
            <h3 className={styles.prblmHeaderTextStyle}>
              {strings.foundiPage.prblmSection.headerText3}
            </h3>
            <div className={styles.unorderedListContainerStyle}>
              <p className={styles.blueTextStyle}>
                {strings.foundiPage.prblmSection.headerText3Desc.mainText1}
              </p>
              <ul className={styles.listContainerStyle}>
                <li className={styles.listTextStyle}>
                  {strings.foundiPage.prblmSection.headerText3Desc.point1[1]}
                </li>
                <li className={styles.listTextStyle}>
                  {strings.foundiPage.prblmSection.headerText3Desc.point1[2]}
                </li>
                <li className={styles.listTextStyle}>
                  {strings.foundiPage.prblmSection.headerText3Desc.point1[3]}
                </li>
              </ul>
            </div>
            <div className={styles.doneContainerStyle}>
              <p className={styles.blueTextStyle}>
                {strings.foundiPage.prblmSection.headerText3Desc.mainText2}
              </p>
              <ul className={styles.listContainerStyle}>
                <li className={styles.listTextStyle}>
                  {strings.foundiPage.prblmSection.headerText3Desc.point2[1]}
                </li>
                <li className={styles.listTextStyle}>
                  {strings.foundiPage.prblmSection.headerText3Desc.point2[2]}
                </li>
                <li className={styles.listTextStyle}>
                  {strings.foundiPage.prblmSection.headerText3Desc.point2[3]}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  };
  const renderDivider = () => {
    return <div className={styles.divderStyles}></div>;
  };
  const renderUnderStandingUserNeedsContainer = () => {
    return (
      <div className={styles.understandingMainContainerStyle}>
        <div className={styles.understandingInsideContainerStyle}>
          <div className={styles.headerOutsideWrapperStyle}>
            <div className={styles.headerWrapperStyle}>
              <p className={styles.uiAndUxSmallTextStyle}>
                {strings.foundiPage.underStandingSection.smallText}
              </p>
              <div className={styles.understandingNeedsHeaderContainerStyle}>
                <p className={styles.numberingStyle}>
                  {strings.foundiPage.underStandingSection.one}
                </p>
                <h2 className={styles.underStandingHeaderStyle}>
                  {strings.foundiPage.underStandingSection.headerText}
                </h2>
              </div>
            </div>
            <ul className={styles.listContainerStyle2}>
              <li className={styles.understandDescTextStyle}>
                {strings.foundiPage.underStandingSection.desc1}
              </li>
              <li className={styles.understandDescTextStyle}>
                {strings.foundiPage.underStandingSection.desc2}
              </li>
              <li className={styles.understandDescTextStyle}>
                {strings.foundiPage.underStandingSection.desc3}
              </li>
            </ul>
          </div>
          <div className={styles.photWrapperStyles}>
            <img src={photo} className={styles.imgStyles2} />
          </div>
        </div>
      </div>
    );
  };
  const renderWireFramesContainer = () => {
    return (
      <div className={styles.understandingMainContainerStyle}>
        <div className={styles.understandingInsideContainerStyle}>
          <div className={styles.headerOutsideWrapperStyle}>
            <div className={styles.headerWrapperStyle}>
              <p className={styles.uiAndUxSmallTextStyle}>
                {strings.foundiPage.wireFramesSection.smallText}
              </p>
              <div className={styles.understandingNeedsHeaderContainerStyle}>
                <p className={styles.numberingStyle}>
                  {strings.foundiPage.wireFramesSection.one}
                </p>
                <h2 className={styles.underStandingHeaderStyle}>
                  {strings.foundiPage.wireFramesSection.headerText}
                </h2>
              </div>
            </div>
            <ul className={styles.listContainerStyle2}>
              <li className={styles.understandDescTextStyle}>
                {strings.foundiPage.wireFramesSection.desc1}
              </li>
              <li className={styles.understandDescTextStyle}>
                {strings.foundiPage.wireFramesSection.desc2}
              </li>
              <li className={styles.understandDescTextStyle}>
                {strings.foundiPage.wireFramesSection.desc3}
              </li>
            </ul>
          </div>
          <div className={styles.imgContainerStyle}>
            <div className={styles.photWrapperStyles}>
              <img src={photo} className={styles.imgStyles2} />
            </div>
            <div className={styles.photWrapperStyles}>
              <img src={photo} className={styles.imgStyles2} />
            </div>
          </div>
        </div>
      </div>
    );
  };
  const renderProtoTypingContainer = () => {
    return (
      <div className={styles.understandingMainContainerStyle}>
        <div className={styles.understandingInsideContainerStyle}>
          <div className={styles.headerOutsideWrapperStyle}>
            <div className={styles.headerWrapperStyle}>
              <p className={styles.uiAndUxSmallTextStyle}>
                {strings.foundiPage.protoTypingSection.smallText}
              </p>
              <div className={styles.understandingNeedsHeaderContainerStyle}>
                <p className={styles.numberingStyle}>
                  {strings.foundiPage.protoTypingSection.one}
                </p>
                <h2 className={styles.underStandingHeaderStyle}>
                  {strings.foundiPage.protoTypingSection.headerText}
                </h2>
              </div>
            </div>
            <ul className={styles.listContainerStyle2}>
              <li className={styles.understandDescTextStyle}>
                {strings.foundiPage.protoTypingSection.desc1}
              </li>
              <li className={styles.understandDescTextStyle}>
                {strings.foundiPage.protoTypingSection.desc2}
              </li>
              <li className={styles.understandDescTextStyle}>
                {strings.foundiPage.protoTypingSection.desc3}
              </li>
            </ul>
          </div>
          <div className={styles.imgContainerStyle}>
            <div className={styles.photWrapperStyles}>
              <img src={photo} className={styles.imgStyles2} />
            </div>
            <div className={styles.photWrapperStyles}>
              <img src={photo} className={styles.imgStyles2} />
            </div>
          </div>
        </div>
      </div>
    );
  };
  const renderAppDevelopMentContainer = () => {
    return (
      <div className={styles.understandingMainContainerStyle}>
        <div className={styles.understandingInsideContainerStyle}>
          <div className={styles.headerOutsideWrapperStyle}>
            <div className={styles.headerWrapperStyle}>
              <p className={styles.uiAndUxSmallTextStyle}>
                {strings.foundiPage.appDevSection.smallText}
              </p>
              <div className={styles.understandingNeedsHeaderContainerStyle}>
                <p className={styles.numberingStyle}>
                  {strings.foundiPage.appDevSection.one}
                </p>
                <h2 className={styles.underStandingHeaderStyle}>
                  {strings.foundiPage.appDevSection.headerText}
                </h2>
              </div>
            </div>
            <p className={styles.understandDescTextStyle}>
              {strings.foundiPage.appDevSection.desc}
            </p>
          </div>
          <div className={styles.photWrapperStyles}>
            <img src={photo} className={styles.imgStyles2} />
          </div>
          <div className={styles.technologyContainerStyle}>
            <p className={styles.technologiesTextStyle}>
              {strings.foundiPage.technologiesSection.technologiesHeaderText}
            </p>
            <div className={styles.technologiesContainerStyle}>
              <div className={styles.technologiesImgAndTextContainerStyle}>
                <div className={styles.technologiesImgStyle}>
                  <img src={webDevBlackImg} className={styles.imgStyles} />
                </div>

                <p className={styles.technologiesNameTextBlackStyle}>
                  {strings.foundiPage.technologiesSection.technologies1}
                </p>
              </div>
              <div className={styles.technologiesImgAndTextContainerStyle}>
                <div className={styles.technologiesImgStyle}>
                  <img src={webDevBlackImg} className={styles.imgStyles} />
                </div>

                <p className={styles.technologiesNameTextBlackStyle}>
                  {strings.foundiPage.technologiesSection.technologies2}
                </p>
              </div>
              <div className={styles.technologiesImgAndTextContainerStyle}>
                <div className={styles.technologiesImgStyle}>
                  <img src={webDevBlackImg} className={styles.imgStyles} />
                </div>
                <p className={styles.technologiesNameTextBlackStyle}>
                  {strings.foundiPage.technologiesSection.technologies3}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  const renderResultsContainer = () => {
    return (
      <div className={styles.resultsContainerStyles}>
        <div className={styles.resultsInsideContainerStyle}>
          <div className={styles.resultsHeaderContainerStyle}>
            <h2 className={styles.headerTextStyle}>
              {strings.foundiPage.resultsSection.headerText}
            </h2>
            <p className={styles.descriptionTextStyle}>
              {strings.foundiPage.resultsSection.desc}
            </p>
          </div>
          <div className={styles.quoteImgDescContainerStyle}>
            <div className={styles.quoteImgContainerStyle}>
              <img src={quoteBlackImg} className={styles.quoteImgStyles} />
            </div>
            <div className={styles.resultBoxDescContainerStyle}>
              <p className={styles.resultsDescTextStyle}>
                {strings.foundiPage.resultsSection.cardDesc}
              </p>
              <div className={styles.clientResultContainerStyle}>
                <div className={styles.resultImgWrapperStyle}>
                  <img src={photoImg} className={styles.imgStyles} />
                </div>
                <div>
                  <p className={styles.nameTextStyle}>
                    {strings.foundiPage.resultsSection.name}
                  </p>
                  <p className={styles.companyTextStyle}>
                    {strings.foundiPage.resultsSection.jobposition}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  return (
    <div className={styles.mainContainerStyle}>
      <Helmet>
        <meta
          name="description"
          content="Discover how ViljeTech helped Foundi create a unique solution to the common problem of lost items. Our collaboration involved brand identity, app and website design, and a QR code-based system that connects users with their possessions. "
        />
        <meta
          name="keywords"
          content="Lost items,QR codes,Brand identity,App development,Website design,User experience,"
        />
        <link
          rel="canonical"
          href="https://www.viljetech.com/projects/foundi"
        />
        <title>ViljeTech | Foundi</title>
      </Helmet>
      <NavBar color={true} backgroundColor={styles.backGroundStyle} />
      <div className={styles.topContainerStyle}>
        <div className={styles.insideContainerStyle}>
          {renderHeaderTopContainer()}
        </div>
      </div>
      <div className={styles.prblmAndSolutionContainerStyle}>
        <div className={styles.insideContainerStyle}>
          {renderPrblmSolutionContainer()}
        </div>
      </div>
      {renderDivider()}
      <div className={styles.prblmAndSolutionContainerStyle}>
        <div className={styles.insideContainerStyle}>
          {renderUnderStandingUserNeedsContainer()}
        </div>
      </div>
      {renderDivider()}
      <div className={styles.prblmAndSolutionContainerStyle}>
        <div className={styles.insideContainerStyle}>
          {renderWireFramesContainer()}
        </div>
      </div>
      {renderDivider()}
      <div className={styles.prblmAndSolutionContainerStyle}>
        <div className={styles.insideContainerStyle}>
          {renderProtoTypingContainer()}
        </div>
      </div>
      {renderDivider()}
      <div className={styles.prblmAndSolutionContainerStyle}>
        <div className={styles.insideContainerStyle}>
          {renderAppDevelopMentContainer()}
        </div>
      </div>
      <div className={styles.topContainerStyle}>
        <div className={styles.insideContainerStyle}>
          {renderResultsContainer()}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default FoundiPage;
