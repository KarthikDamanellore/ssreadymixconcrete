import React from "react";
import styles from "./styles.module.css";
import NavBar from "../../../components/NavBar";
import Footer from "../../../components/Footer";
import blogImg from "../../../assets/images/blogImg.svg";

const BlogPost = () => {
  const blogContent = [
    {
      id: 1,
      header: "Content Generation",
      content:
        "One of the key factors that affects a website`s ranking in SERPs is the quality and relevance of its content. Chat-GPT can help you generate high-quality, relevant content that is optimized for both search engines and users. Whether you need blog posts, product descriptions, or page content, Chat-GPT can help you create content that is engaging, informative, and SEO-friendly.",
    },
    {
      id: 2,
      header: "Keyword Optimization",
      content:
        "Another important factor in SEO is keyword optimization. Chat-GPT can help you identify the best keywords for your website and optimize your content for those keywords. This includes both on-page optimization, such as using keywords in your content and meta tags, as well as off-page optimization, such as building high-quality backlinks to your site.",
    },
    {
      id: 3,
      header: "Site Structure and Navigation",
      content:
        "Site structure and navigation are also critical components of SEO. Chat-GPT can help you create a site structure that is easy to navigate, both for users and search engines. This includes organizing your content into categories, using clear and descriptive URLs, and providing clear and intuitive navigation links.",
    },
    {
      id: 4,
      header: "Technical SEO",
      content:
        "Finally, technical SEO is another important factor in optimizing your website for search engines. Chat-GPT can help you ensure that your site is technically sound, with fast loading times, a mobile-friendly design, and clean and validated HTML code. These technical optimizations can help improve your website`s ranking in SERPs and ensure that your site is accessible and usable for both users and search engines.",
    },
    {
      id: 5,
      header: "Conclusion",
      content:
        "In conclusion, using Chat-GPT can help you improve your website`s SEO and drive more traffic to your site. From generating high-quality content to optimizing keywords and site structure, Chat-GPT can help you create a website that is optimized for both users and search engines. By following best practices for SEO and using Chat-GPT to support your efforts, you can achieve better rankings, increased traffic, and ultimately, better results for your business.",
    },
  ];
  return (
    <div>
      <NavBar backgroundColor={styles.backGroundStyle} />
      <div className={styles.blogpostOuterContainerStyle}>
        <div className={styles.blogPostMainContainerStyle}>
          <h1 className={styles.blogpostHeaderTextStyle}>
            How using Chat-GPT can improve your site’s SEO
          </h1>
          <div className={styles.blogImgWrapperStyle}>
            <img src={blogImg} className={styles.imgStyle} />
          </div>
          <p className={styles.blogContentTextStyle}>
            Search engine optimization (SEO) is a critical component of website
            design and development. The goal of SEO is to improve a website's
            ranking in search engine results pages (SERPs), which can lead to
            increased traffic, brand recognition, and ultimately, sales. In this
            article, we'll explore how using Chat-GPT can help you improve your
            website's SEO and drive more traffic to your site.
          </p>
        </div>
      </div>

      <div className={styles.blogpostContentWrapperStyle}>
        <div className={styles.blogPostContentInnerWrapperStyle}>
          {blogContent.map((item, index) => {
            return (
              <div
                key={"blog" + item.id}
                className={styles.blogContentItemWrapperStyle}
              >
                <h2 className={styles.blogPostContentHeaderTextStyle}>
                  {item.header}
                </h2>
                <p className={styles.blogPostContentDescTextStyle}>
                  {item.content}
                </p>
              </div>
            );
          })}

          <p className={styles.blogAuthorTextStyle}>
            - Ida Alfonsi, Communication Manager, Vilje Tech
          </p>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default BlogPost;
