import React from "react";
import styles from "./styles.module.css";
import NavBar from "../../../components/NavBar";
import Footer from "../../../components/Footer";
import blogImg from "../../../assets/images/blogImg.svg";

const BlogList = () => {
  const blogData = [
    {
      id: 1,
      image: blogImg,
      headerText: "How using Chat-GPT can improve your site’s SEO",
      desc: "Search engine optimization (SEO) is a critical component of website design and development. The goal of SEO is to improve a website`s ranking in search engine results pages (SERPs), which can lead to increased traffic, brand recognition, and ultimately, sales.",
    },
    {
      id: 2,
      image: blogImg,
      headerText: "How using Chat-GPT can improve your site’s SEO",
      desc: "Search engine optimization (SEO) is a critical component of website design and development. The goal of SEO is to improve a website`s ranking in search engine results pages (SERPs), which can lead to increased traffic, brand recognition, and ultimately, sales.",
    },
    {
      id: 3,
      image: blogImg,
      headerText: "How using Chat-GPT can improve your site’s SEO",
      desc: "Search engine optimization (SEO) is a critical component of website design and development. The goal of SEO is to improve a website`s ranking in search engine results pages (SERPs), which can lead to increased traffic, brand recognition, and ultimately, sales.",
    },
    {
      id: 4,
      image: blogImg,
      headerText: "How using Chat-GPT can improve your site’s SEO",
      desc: "Search engine optimization (SEO) is a critical component of website design and development. The goal of SEO is to improve a website`s ranking in search engine results pages (SERPs), which can lead to increased traffic, brand recognition, and ultimately, sales.",
    },
    {
      id: 5,
      image: blogImg,
      headerText: "How using Chat-GPT can improve your site’s SEO",
      desc: "Search engine optimization (SEO) is a critical component of website design and development. The goal of SEO is to improve a website`s ranking in search engine results pages (SERPs), which can lead to increased traffic, brand recognition, and ultimately, sales.",
    },
  ];
  return (
    <div>
      <NavBar color={true} />
      <div className={styles.bloglistMainContainerStyle}>
        <h1 className={styles.blogListHeaderTextStyle}>Blog posts</h1>
        <div className={styles.dividerLineStyle}></div>
        <div className={styles.blogListContainerStyle}>
          {blogData.map((item, index) => {
            return (
              <div
                className={styles.blogListItemWrapperStyle}
                key={"blog" + item.id}
              >
                <div className={styles.blogImgListWrapperStyle}>
                  <img src={item.image} className={styles.imgStyle} />
                </div>
                <div className={styles.blogListItemContentWrapperStyle}>
                  <p className={styles.blogListItemHeaderTextStyle}>
                    {item.headerText}
                  </p>
                  <p className={styles.blogListItemContentTextStyle}>
                    {item.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default BlogList;
