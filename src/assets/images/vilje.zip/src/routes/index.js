import React from "react";
import { Routes, Route } from "react-router-dom";
import {
  HomePage,
  AboutPage,
  ContactPage,
  ProjectsPage,
  ServicesPage,
  CommingSoonPage,
  PrizbeePage,
  BytbooPage,
  FoundiPage,
  ImviPage,
  BlogList,
  BlogPost,
} from "../pages";

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/home" element={<HomePage />} />
      <Route path="/about" element={<AboutPage />} />
      <Route path="/contact" element={<ContactPage />} />
      <Route path="/projects" element={<ProjectsPage />} />
      <Route path="/services" element={<ServicesPage />} />
      <Route path="/projects/imvi" element={<ImviPage />} />
      <Route path="/projects/foundi" element={<FoundiPage />} />
      <Route path="/projects/bytboo" element={<BytbooPage />} />
      <Route path="/projects/prizbee" element={<PrizbeePage />} />
      <Route path="/bloglist" element={<BlogList />} />
      <Route path="/blogpost" element={<BlogPost />} />
      {/* <Route path="*" element={<CommingSoonPage />} /> */}
    </Routes>
  );
}

export default AppRoutes;
